thank you for downloading the simulator. Simply copy the whole folder somewhere onto your drive, enter the child folder 
and run the executable application. 

Jump below if you are panicking /
/
/
/
/
//
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
/
This was a harmless "ransomware" that is spreading the gospel.
but ok, ok. you've confessed. you have to ask the Lord for forgiveness now. Simply input 
"Forgive me Father" into the confession box and your files will be returned to you. If 
you're an idiot, and it doesn't work (your fault) simply rename your files with the correct extension 
or use a hex editor like FHRED

thank you for putting your faith in Jesus Christ, the one true Triune God!
